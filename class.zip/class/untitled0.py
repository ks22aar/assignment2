

import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns

# read data
def reading_data(name):
    '''
    this function read data and return in the required form
    '''
    # read data
    df = pd.read_csv(name,skiprows=4)
    
    original_data=df.drop(['Country Code', 'Indicator Code'],axis=1)
    
    countries_data=df.drop(['Country Code', 'Indicator Name', 'Indicator Code'],axis=1)
    
    year_data= df.drop(['Country Name', 'Country Code', 'Indicator Name', 'Indicator Code',],axis=1).T
    
    year_data.index.name='Years'
    
    # print header data
    print(year_data.head)
    print(countries_data.head)
    print(original_data.head)
    print(original_data.T)
    
    # return data transpose and original data with year as column and country as column
    return countries_data,year_data,original_data

    # plot a lie graph
def graph_line_plot(data,indicator,indicator_name):
    '''
    this function plot graph line plot of specific country 
    '''
    # create a dataframe
    factor_data=data[data["Indicator Name"]==indicator]
    
    uk_data=factor_data[factor_data["Country Name"]=="United Kingdom"].drop(['Country Name','Indicator Name'],axis=1)

    us_data=factor_data[factor_data["Country Name"]=="United States"].drop(['Country Name','Indicator Name'],axis=1)
    
    uae_data=factor_data[factor_data["Country Name"]=="United Arab Emirates"].drop(['Country Name','Indicator Name'],axis=1)
    
    china_data=factor_data[factor_data["Country Name"]=="China"].drop(['Country Name','Indicator Name'],axis=1)
  
    # get year data from data frame
    year=data.drop(['Country Name','Indicator Name'],axis=1).T.index
    
    print(year)
    
    # plotting the points 
    plt.plot(pd.to_numeric(year[0:62].to_numpy()),uk_data.iloc[0].dropna().to_numpy() , label = "United Kingdom",linestyle="-.")
    plt.plot(pd.to_numeric(year[0:62].to_numpy()),us_data.iloc[0].dropna().to_numpy() , label = "United States",linestyle="-.")
    plt.plot(pd.to_numeric(year[0:62].to_numpy()),uae_data.iloc[0].dropna().to_numpy() , label = "United Arab Emirates",linestyle="-.")
    plt.plot(pd.to_numeric(year[0:62].to_numpy()),china_data.iloc[0].dropna().to_numpy() , label = "China",linestyle="-.")
    
      
    # naming the x axis
    plt.xlabel('year')
    # naming the y axis
    plt.ylabel('data')
    plt.legend()
    # giving a title to my graph
    plt.title(indicator_name)
      
    # function to show the plot
    plt.show()
    
   
    
 # plot a bar graoh  
def graph_bar_plot(data,indicator,indicator_name):
    '''
    this function draw bar plot graph for the 4 countries year 1995 to 2020
    '''
    #  creating a data frame
    factor_data=data[data["Indicator Name"]==indicator]
    
    uk_data=factor_data[factor_data["Country Name"]=="United Kingdom"].drop(['Country Name','Indicator Name'],axis=1)

    us_data=factor_data[factor_data["Country Name"]=="United States"]
    
    uae_data=factor_data[factor_data["Country Name"]=="United Arab Emirates"]
    
    china_data=factor_data[factor_data["Country Name"]=="China"]
    
    index = ['1995', '2000', '2005',
          '2010', '2015', '2020']
    
    df = pd.DataFrame({'China':  [china_data['1995'].iloc[0],china_data['2000'].iloc[0],china_data['2005'].iloc[0],china_data['2010'].iloc[0],china_data['2015'].iloc[0],china_data['2020'].iloc[0],],
                       'United States': [us_data['1995'].iloc[0],us_data['2000'].iloc[0],us_data['2005'].iloc[0],us_data['2010'].iloc[0],us_data['2015'].iloc[0],us_data['2020'].iloc[0],],
                    'United Kingdom':  [uk_data['1995'].iloc[0],uk_data['2000'].iloc[0],uk_data['2005'].iloc[0],uk_data['2010'].iloc[0],uk_data['2015'].iloc[0],uk_data['2020'].iloc[0],],
                    'United Arab Emirates':  [uae_data['1995'].iloc[0],uae_data['2000'].iloc[0],uae_data['2005'].iloc[0],uae_data['2010'].iloc[0],uae_data['2015'].iloc[0],uae_data['2020'].iloc[0],],
                    
                    }, index=index)
    
    # ploting bar graph
    ax = df.plot.barh(title=indicator_name)
    
    plt.show()

# plot a heatmap with annotation
def correlation_heatmap_us(data,name):
    '''
    this function show heatmap and thier correaltion between indicators for better understanding
    '''
    
    #condition for countries specific data
    if (name=='us'):
        
        # create data frame
        factor_data=pd.DataFrame()
        
        # getting indicator data
        us_data=data[data["Indicator Name"]=="Urban population"]
        
        # get united states data 
        us_urban=us_data[us_data['Country Name']=="United States"].drop(['Country Name','Indicator Name'],axis=1).T
        
        # drop nan values
        us_urban=us_urban.dropna().T
        
        # get urban population data
        factor_data["Urban population"]=us_urban.iloc[0]
        
        #  get arable data
        us_data=data[data["Indicator Name"]=='Arable land (% of land area)']
        
        
        us_urban=us_data[us_data['Country Name']=="United States"].drop(['Country Name','Indicator Name'],axis=1).T
        
        us_urban=us_urban.dropna().T
        
        factor_data['Arable land (% of land area)']=us_urban.iloc[0]
        
        #  get cereal data
        us_data=data[data["Indicator Name"]=='Cereal yield (kg per hectare)']
        
        us_urban=us_data[us_data['Country Name']=="United States"].drop(['Country Name','Indicator Name'],axis=1).T
        
        us_urban=us_urban.dropna().T
        
        factor_data['Cereal yield (kg per hectare)']=us_urban.iloc[0]
        
        us_data=data[data["Indicator Name"]=='Population, total']
        
        us_urban=us_data[us_data['Country Name']=="United States"].drop(['Country Name','Indicator Name'],axis=1).T
        
        us_urban=us_urban.dropna().T
        
        factor_data['Population, total']=us_urban.iloc[0]
        
        # plot a heatmap with annotation
        
        ax = plt.axes()
        
        # plot heatmap
        heatmap = sns.heatmap(factor_data.corr(), cmap="tab10",
                             
                annot=True,ax=ax
                
                )
        # add title
        ax.set_title('United States')
        
        plt.show()
        
    elif(name=='uk'):
        # get dataframe
        factor_data=pd.DataFrame()
        
        # get urban population
        uk_data=data[data["Indicator Name"]=="Urban population"]
        
        # get UK data
        uk_urban=uk_data[uk_data['Country Name']=="United Kingdom"].drop(['Country Name','Indicator Name'],axis=1).T
        
        # drop nan value
        uk_urban=uk_urban.dropna().T
        
        factor_data["Urban population"]=uk_urban.iloc[0]
        
        uk_data=data[data["Indicator Name"]=='Arable land (% of land area)']
        
        uk_urban=uk_data[uk_data['Country Name']=="United Kingdom"].drop(['Country Name','Indicator Name'],axis=1).T
        
        uk_urban=uk_urban.dropna().T
        
        # get arabledata
        factor_data['Arable land (% of land area)']=uk_urban.iloc[0]
        
        # get cereal data
        uk_data=data[data["Indicator Name"]=='Cereal yield (kg per hectare)']
        
        uk_urban=uk_data[uk_data['Country Name']=="United Kingdom"].drop(['Country Name','Indicator Name'],axis=1).T
        
        uk_urban=uk_urban.dropna().T
        
        factor_data['Cereal yield (kg per hectare)']=uk_urban.iloc[0]
        
        uk_data=data[data["Indicator Name"]=='Population, total']
        
        uk_urban=uk_data[uk_data['Country Name']=="United Kingdom"].drop(['Country Name','Indicator Name'],axis=1).T
        
        uk_urban=uk_urban.dropna().T
        
        # get total population
        factor_data['Population, total']=uk_urban.iloc[0]
        
        # plot a heatmap with annotation
        ax = plt.axes()
        
        # plot heat map
        heatmap = sns.heatmap(factor_data.corr(), cmap="tab10",
                annot=True,ax=ax
                
                )
        
        # set title
        ax.set_title('United Kingdom')
        
        plt.show()
        
    elif(name=='china'):
        
        # crete panda dataframe
        factor_data=pd.DataFrame()
        
        #  get uk urba  population  data
        uk_data=data[data["Indicator Name"]=="Urban population"]
        
        uk_urban=uk_data[uk_data['Country Name']=="China"].drop(['Country Name','Indicator Name'],axis=1).T
        
        # drop nan value
        uk_urban=uk_urban.dropna().T
        
        factor_data["Urban population"]=uk_urban.iloc[0]
        
        # get arable data
        uk_data=data[data["Indicator Name"]=='Arable land (% of land area)']
        
        uk_urban=uk_data[uk_data['Country Name']=="China"].drop(['Country Name','Indicator Name'],axis=1).T
        
        uk_urban=uk_urban.dropna().T
        
        factor_data['Arable land (% of land area)']=uk_urban.iloc[0]
        
        uk_data=data[data["Indicator Name"]=='Cereal yield (kg per hectare)']
        
        uk_urban=uk_data[uk_data['Country Name']=="China"].drop(['Country Name','Indicator Name'],axis=1).T
        
        uk_urban=uk_urban.dropna().T
        
        #  cereal yield data
        factor_data['Cereal yield (kg per hectare)']=uk_urban.iloc[0]
        
        #  get total population data
        uk_data=data[data["Indicator Name"]=='Population, total']
        
        uk_urban=uk_data[uk_data['Country Name']=="China"].drop(['Country Name','Indicator Name'],axis=1).T
        
        uk_urban=uk_urban.dropna().T
        
        factor_data['Population, total']=uk_urban.iloc[0]
        
        # plot a heatmap with annotation
        ax = plt.axes()
        
        heatmap = sns.heatmap(factor_data.corr(), cmap="tab10",
                annot=True,ax=ax
                
                )
        
        # set title
        ax.set_title(name)
        
        plt.show()  
        
    elif(name=='uae'):
        
        # get dataframe
        factor_data=pd.DataFrame()
        
        # uk urban population
        uk_data=data[data["Indicator Name"]=="Urban population"]
        
        # uk data
        uk_urban=uk_data[uk_data['Country Name']=="United Arab Emirates"].drop(['Country Name','Indicator Name'],axis=1).T
        
        uk_urban=uk_urban.dropna().T
        
        #  urban data
        factor_data["Urban population"]=uk_urban.iloc[0]
        
        uk_data=data[data["Indicator Name"]=='Arable land (% of land area)']
        
        uk_urban=uk_data[uk_data['Country Name']=="United Arab Emirates"].drop(['Country Name','Indicator Name'],axis=1).T
        
        # drop nan value
        uk_urban=uk_urban.dropna().T
        
        factor_data['Arable land (% of land area)']=uk_urban.iloc[0]
        
        uk_data=data[data["Indicator Name"]=='Cereal yield (kg per hectare)']
        
        uk_urban=uk_data[uk_data['Country Name']=="United Arab Emirates"].drop(['Country Name','Indicator Name'],axis=1).T
        
        uk_urban=uk_urban.dropna().T
        
        factor_data['Cereal yield (kg per hectare)']=uk_urban.iloc[0]
        
        uk_data=data[data["Indicator Name"]=='Population, total']
        
        uk_urban=uk_data[uk_data['Country Name']=="United Arab Emirates"].drop(['Country Name','Indicator Name'],axis=1).T
        
        uk_urban=uk_urban.dropna().T
        
        #  population data
        factor_data['Population, total']=uk_urban.iloc[0]
        
        # plot a heatmap with annotation
        ax = plt.axes()
        
        heatmap = sns.heatmap(factor_data.corr(), cmap="tab10",
                annot=True,ax=ax
                
                )
        
        #  set title
        ax.set_title('United Arab Emirates')
        
        plt.show()
    
    
    
    
    
    # main function
if __name__ == "__main__":
    
    country_data,year_data,original_data=reading_data("data.csv")
    
    graph_bar_plot(original_data,'Arable land (% of land area)','Arable land (% of land area)')
    
    graph_bar_plot(original_data,'Cereal yield (kg per hectare)','Cereal yield (kg per hectare)')
    
    graph_line_plot(original_data, 'Population, total','Population, total')
    
    graph_line_plot(original_data, 'Urban population','Urban population')
    
    correlation_heatmap_us(original_data,"us")
    
    correlation_heatmap_us(original_data,"uk")
    
    correlation_heatmap_us(original_data,"uae")
    
    correlation_heatmap_us(original_data,"china")
